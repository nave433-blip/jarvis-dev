# JARVIS: Local AI Coding Assistant

JARVIS is a senior software engineering assistant that runs locally on macOS, powered by Ollama. It combines voice commands, vector memory, and proactive file monitoring with a Gemini-inspired structured agent workflow.

## Features

- **Gemini-Like Agent:** Structured Research -> Strategy -> Execution loop.
- **Surgical Editing:** Precise file modifications without rewriting entire files.
- **Vector Memory:** Remembers past tasks and analyses using Ollama-powered embeddings.
- **Voice Commands:** Control Jarvis using your voice (Speech-to-Text).
- **Proactive Monitoring:** Automatically analyzes file changes in the background.
- **Safe Shell:** Integrated shell tool with built-in safety checks.

## Installation

### Method 1: Curl Install (One-liner)
```bash
curl -fsSL https://raw.githubusercontent.com/nave433-blip/jarvis-dev/main/install.sh | bash
```

### Method 2: Homebrew
```bash
brew install nave433-blip/tap/jarvis
```

### Method 3: Git (Developer Install)
1. **Requirements:**
   - Python 3.9+
   - [Ollama](https://ollama.com/) (running `llama3`)
   - PortAudio (for voice: `brew install portaudio`)

2. **Setup:**
   ```bash
   git clone https://github.com/nave433-blip/jarvis-dev.git
   cd jarvis-dev
   python3 -m venv venv
   source venv/bin/activate
   pip install -e .
   ```

## Usage

Run Jarvis from anywhere (if aliased):

```bash
jarvis chat "Explain the current project structure"
jarvis fix "Fix the bug in memory/vector.py"
jarvis voice
jarvis watch
```

## Project Rules

Custom instructions can be added to `JARVIS.md` to guide the AI's behavior.
